#!/usr/bin/env python3

import math
import time
from typing import Dict

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
from std_msgs.msg import UInt32
from std_srvs.srv import SetBool


JOINTS = ["waist", "shoulder", "elbow", "wrist", "gripper"]

# HOME definido como referencia del laboratorio
HOME = {
    "waist": 0.0,
    "shoulder": 0.0,
    "elbow": 0.0,
    "wrist": 0.0,
    "gripper": 0.0,
}

# Pruebas iniciales conservadoras para Actividad 4
# Ajusta estos valores si alguna posición no es segura en tu robot.
TESTS = {
    "waist": [-20.0, 0.0, 20.0],
    "shoulder": [-15.0, 0.0, 15.0],
    "elbow": [-15.0, 0.0, 15.0],
    "wrist": [-20.0, 0.0, 20.0],
    "gripper": [0.0, 15.0, 30.0],
}


class Activity4Individual(Node):
    def __init__(self):
        super().__init__("activity4_individual")

        self.cmd_pub = self.create_publisher(
            JointState,
            "/pincher/command",
            10,
        )

        self.speed_pub = self.create_publisher(
            UInt32,
            "/pincher/profile_velocity",
            10,
        )

        self.torque_client = self.create_client(
            SetBool,
            "/pincher/torque_enable",
        )

        # Pequeña espera para que ROS conecte publicadores y suscriptores
        time.sleep(1.0)

    def set_speed(self, speed: int):
        msg = UInt32()
        msg.data = int(speed)

        # Se publica varias veces por seguridad al inicio
        for _ in range(3):
            self.speed_pub.publish(msg)
            time.sleep(0.1)

        self.get_logger().info(f"Velocidad enviada: {speed}")

    def set_torque(self, enabled: bool):
        if not self.torque_client.wait_for_service(timeout_sec=3.0):
            self.get_logger().warning(
                "No se encontró el servicio /pincher/torque_enable. "
                "Puedes activar el torque manualmente desde la GUI."
            )
            return False

        req = SetBool.Request()
        req.data = enabled

        future = self.torque_client.call_async(req)
        rclpy.spin_until_future_complete(self, future)

        if future.result() is None:
            self.get_logger().warning("No hubo respuesta del servicio de torque.")
            return False

        self.get_logger().info(future.result().message)
        return future.result().success

    def send_pose(self, pose_deg: Dict[str, float], label: str = "", hold: float = 2.0):
        msg = JointState()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.name = JOINTS

        # El controlador espera radianes, pero aquí escribimos grados
        msg.position = [
            math.radians(pose_deg[joint])
            for joint in JOINTS
        ]

        self.cmd_pub.publish(msg)

        text = ", ".join([f"{j}={pose_deg[j]:.1f}°" for j in JOINTS])
        self.get_logger().info(f"{label} -> {text}")

        time.sleep(hold)

    def run_activity(self):
        self.get_logger().info("Iniciando Actividad 4: movimiento individual.")

        # Velocidad baja para las primeras pruebas reales
        self.set_speed(20)

        # Activar torque
        self.set_torque(True)

        # Ir a HOME
        self.send_pose(HOME, "HOME inicial", hold=2.0)

        # Mover una articulación a la vez
        for joint_name, values in TESTS.items():
            self.get_logger().info(f"Probando articulación: {joint_name}")

            for value in values:
                pose = dict(HOME)
                pose[joint_name] = value

                self.send_pose(
                    pose,
                    label=f"{joint_name} -> {value:.1f}°",
                    hold=2.0,
                )

            # Regresar a referencia después de probar esa articulación
            self.send_pose(
                HOME,
                label=f"Retorno a HOME después de {joint_name}",
                hold=2.0,
            )

        self.send_pose(HOME, "HOME final", hold=2.0)

        self.get_logger().info("Actividad 4 finalizada.")


def main():
    rclpy.init()

    node = Activity4Individual()

    try:
        node.run_activity()
    except KeyboardInterrupt:
        node.get_logger().warning("Rutina detenida por el usuario.")
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()