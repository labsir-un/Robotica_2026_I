#!/usr/bin/env python3

import math
import threading
import time
import tkinter as tk
from tkinter import ttk, messagebox

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
from std_msgs.msg import UInt32
from std_srvs.srv import SetBool


JOINTS = ["waist", "shoulder", "elbow", "wrist", "gripper"]
JOINT_LABELS = ["Base/Waist", "Hombro/Shoulder", "Codo/Elbow", "Muñeca/Wrist", "Pinza/Gripper"]

# Configuraciones Actividad 7: [base, hombro, codo, muñeca, pinza]
ACT7_CONFIGS = {
    "C1: 0, 0, 0, 0, 0": [0.0, 0.0, 0.0, 0.0, 0.0],
    "C2: 25, 25, 20, -20, 0": [25.0, 25.0, 20.0, -20.0, 0.0],
    "C3: -35, 35, -30, 30, 0": [-35.0, 35.0, -30.0, 30.0, 0.0],
    "C4: 85, -20, 55, 25, 0": [85.0, -20.0, 55.0, 25.0, 0.0],
    "C5: 80, -35, 55, -45, 0": [80.0, -35.0, 55.0, -45.0, 0.0],
}

# Límites iniciales de seguridad en grados.
# Ajústalos según los límites reales que ustedes determinen en la Actividad 6.
LIMITS = {
    "waist": (-90.0, 90.0),
    "shoulder": (-45.0, 45.0),
    "elbow": (-70.0, 70.0),
    "wrist": (-70.0, 70.0),
    "gripper": (0.0, 40.0),
}


class PincherGuiNode(Node):
    def __init__(self):
        super().__init__("gui_movimiento_simultaneo")

        self.cmd_pub = self.create_publisher(
            JointState,
            "/pincher/command",
            10,
        )

        self.speed_pub = self.create_publisher(
            UInt32,
            "/pincher/profile_velocity",
            10,
        )

        self.joint_sub = self.create_subscription(
            JointState,
            "/joint_states",
            self.joint_state_callback,
            10,
        )

        self.torque_client = self.create_client(
            SetBool,
            "/pincher/torque_enable",
        )

        self.last_positions_deg = {joint: None for joint in JOINTS}

    def joint_state_callback(self, msg):
        for name, pos_rad in zip(msg.name, msg.position):
            if name in self.last_positions_deg:
                self.last_positions_deg[name] = math.degrees(pos_rad)

    def publish_speed(self, speed):
        msg = UInt32()
        msg.data = int(speed)

        for _ in range(3):
            self.speed_pub.publish(msg)
            time.sleep(0.05)

    def publish_pose_deg(self, pose_deg):
        msg = JointState()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.name = JOINTS
        msg.position = [math.radians(q) for q in pose_deg]

        # Publicar varias veces ayuda a que el controlador reciba el comando.
        for _ in range(5):
            self.cmd_pub.publish(msg)
            time.sleep(0.05)

    def set_torque(self, enabled):
        if not self.torque_client.wait_for_service(timeout_sec=1.0):
            return False, "No se encontró /pincher/torque_enable. Usa Torque ON/OFF desde la GUI original."

        req = SetBool.Request()
        req.data = bool(enabled)

        future = self.torque_client.call_async(req)
        return True, future


class SimultaneousControlGUI:
    def __init__(self, root, ros_node):
        self.root = root
        self.node = ros_node
        self.running_sequence = False

        self.root.title("Actividad 7 - Movimiento simultáneo PhantomX Pincher X100")
        self.root.geometry("760x520")

        self.entries = {}
        self.measured_vars = {}
        self.status_var = tk.StringVar(value="Listo. Verifica en RViz antes de mover el robot real.")

        self.speed_var = tk.StringVar(value="20")
        self.scale_var = tk.StringVar(value="1.0")
        self.hold_var = tk.StringVar(value="4.0")

        self.build_layout()
        self.update_measured_positions()

    def build_layout(self):
        title = ttk.Label(
            self.root,
            text="Movimiento simultáneo - PhantomX Pincher X100",
            font=("Arial", 16, "bold"),
        )
        title.pack(pady=10)

        main_frame = ttk.Frame(self.root)
        main_frame.pack(fill="both", expand=True, padx=15, pady=5)

        input_frame = ttk.LabelFrame(main_frame, text="Posiciones articulares deseadas [grados]")
        input_frame.pack(fill="x", pady=5)

        ttk.Label(input_frame, text="Articulación").grid(row=0, column=0, padx=5, pady=5)
        ttk.Label(input_frame, text="Deseada [°]").grid(row=0, column=1, padx=5, pady=5)
        ttk.Label(input_frame, text="Medida /joint_states [°]").grid(row=0, column=2, padx=5, pady=5)
        ttk.Label(input_frame, text="Límite recomendado [°]").grid(row=0, column=3, padx=5, pady=5)

        for i, (joint, label) in enumerate(zip(JOINTS, JOINT_LABELS), start=1):
            ttk.Label(input_frame, text=label).grid(row=i, column=0, sticky="w", padx=5, pady=4)

            entry = ttk.Entry(input_frame, width=12)
            entry.insert(0, "0.0")
            entry.grid(row=i, column=1, padx=5, pady=4)
            self.entries[joint] = entry

            measured = tk.StringVar(value="---")
            ttk.Label(input_frame, textvariable=measured, width=18).grid(row=i, column=2, padx=5, pady=4)
            self.measured_vars[joint] = measured

            lo, hi = LIMITS[joint]
            ttk.Label(input_frame, text=f"{lo:.1f} a {hi:.1f}").grid(row=i, column=3, padx=5, pady=4)

        control_frame = ttk.LabelFrame(main_frame, text="Control general")
        control_frame.pack(fill="x", pady=8)

        ttk.Label(control_frame, text="Velocidad:").grid(row=0, column=0, padx=5, pady=5, sticky="e")
        ttk.Entry(control_frame, textvariable=self.speed_var, width=8).grid(row=0, column=1, padx=5, pady=5)

        ttk.Button(control_frame, text="Aplicar velocidad", command=self.apply_speed).grid(row=0, column=2, padx=5, pady=5)

        ttk.Label(control_frame, text="Escala:").grid(row=0, column=3, padx=5, pady=5, sticky="e")
        ttk.Entry(control_frame, textvariable=self.scale_var, width=8).grid(row=0, column=4, padx=5, pady=5)

        ttk.Label(control_frame, text="Tiempo entre poses [s]:").grid(row=0, column=5, padx=5, pady=5, sticky="e")
        ttk.Entry(control_frame, textvariable=self.hold_var, width=8).grid(row=0, column=6, padx=5, pady=5)

        button_frame = ttk.Frame(main_frame)
        button_frame.pack(fill="x", pady=5)

        ttk.Button(button_frame, text="Enviar posiciones", command=self.send_current_entries).grid(row=0, column=0, padx=5, pady=5)
        ttk.Button(button_frame, text="HOME", command=self.send_home).grid(row=0, column=1, padx=5, pady=5)
        ttk.Button(button_frame, text="Torque ON", command=lambda: self.set_torque(True)).grid(row=0, column=2, padx=5, pady=5)
        ttk.Button(button_frame, text="Torque OFF", command=lambda: self.set_torque(False)).grid(row=0, column=3, padx=5, pady=5)
        ttk.Button(button_frame, text="PARADA SOFTWARE", command=self.software_stop).grid(row=0, column=4, padx=5, pady=5)

        config_frame = ttk.LabelFrame(main_frame, text="Configuraciones Actividad 7")
        config_frame.pack(fill="x", pady=8)

        row = 0
        col = 0
        for name, config in ACT7_CONFIGS.items():
            ttk.Button(
                config_frame,
                text=name,
                command=lambda c=config: self.load_config(c),
            ).grid(row=row, column=col, padx=5, pady=5, sticky="ew")

            col += 1
            if col >= 2:
                col = 0
                row += 1

        ttk.Button(
            config_frame,
            text="Ejecutar secuencia completa Actividad 7",
            command=self.run_activity7_sequence,
        ).grid(row=row + 1, column=0, columnspan=2, padx=5, pady=8, sticky="ew")

        status_frame = ttk.LabelFrame(main_frame, text="Estado")
        status_frame.pack(fill="both", expand=True, pady=8)

        ttk.Label(
            status_frame,
            textvariable=self.status_var,
            wraplength=700,
            justify="left",
        ).pack(anchor="w", padx=10, pady=10)

    def get_scale(self):
        try:
            scale = float(self.scale_var.get())
        except ValueError:
            raise ValueError("La escala debe ser numérica.")

        if scale <= 0:
            raise ValueError("La escala debe ser mayor que cero.")

        return scale

    def get_hold_time(self):
        try:
            hold = float(self.hold_var.get())
        except ValueError:
            raise ValueError("El tiempo entre poses debe ser numérico.")

        if hold < 0.5:
            raise ValueError("Usa al menos 0.5 s entre poses.")

        return hold

    def read_entries(self):
        pose = []

        for joint in JOINTS:
            text = self.entries[joint].get().strip()

            try:
                value = float(text)
            except ValueError:
                raise ValueError(f"Valor inválido en {joint}: {text}")

            lo, hi = LIMITS[joint]
            if value < lo or value > hi:
                raise ValueError(
                    f"{joint} = {value:.1f}° está fuera del límite recomendado "
                    f"[{lo:.1f}, {hi:.1f}]°."
                )

            pose.append(value)

        return pose

    def load_config(self, config):
        for joint, value in zip(JOINTS, config):
            self.entries[joint].delete(0, tk.END)
            self.entries[joint].insert(0, f"{value:.1f}")

        self.status_var.set("Configuración cargada. Presiona 'Enviar posiciones' para ejecutarla.")

    def apply_speed(self):
        try:
            speed = int(float(self.speed_var.get()))
            if speed <= 0:
                raise ValueError
        except ValueError:
            messagebox.showerror("Error", "La velocidad debe ser un número positivo.")
            return

        self.node.publish_speed(speed)
        self.status_var.set(f"Velocidad enviada: {speed}")

    def send_pose(self, pose_deg, label="Posición enviada"):
        scale = self.get_scale()
        pose_scaled = [q * scale for q in pose_deg]

        for joint, value in zip(JOINTS, pose_scaled):
            lo, hi = LIMITS[joint]
            if value < lo or value > hi:
                raise ValueError(
                    f"{joint} escalado = {value:.1f}° está fuera del límite recomendado "
                    f"[{lo:.1f}, {hi:.1f}]°."
                )

        self.node.publish_pose_deg(pose_scaled)

        text = ", ".join([f"{j}={q:.1f}°" for j, q in zip(JOINTS, pose_scaled)])
        self.status_var.set(f"{label}: {text}")

    def send_current_entries(self):
        try:
            pose = self.read_entries()
            self.send_pose(pose, "Comando simultáneo enviado")
        except ValueError as e:
            messagebox.showerror("Error de entrada", str(e))

    def send_home(self):
        try:
            self.send_pose([0.0, 0.0, 0.0, 0.0, 0.0], "HOME enviado")
        except ValueError as e:
            messagebox.showerror("Error", str(e))

    def set_torque(self, enabled):
        ok, result = self.node.set_torque(enabled)

        if not ok:
            self.status_var.set(result)
            return

        self.status_var.set("Solicitud de torque enviada. Verifica el estado del robot.")

    def software_stop(self):
        self.running_sequence = False
        self.set_torque(False)
        self.status_var.set(
            "PARADA SOFTWARE ejecutada: secuencia detenida y solicitud de Torque OFF enviada. "
            "Esto no reemplaza el corte físico de energía."
        )

    def run_activity7_sequence(self):
        if self.running_sequence:
            messagebox.showinfo("Secuencia activa", "Ya hay una secuencia en ejecución.")
            return

        self.running_sequence = True
        thread = threading.Thread(target=self._activity7_worker, daemon=True)
        thread.start()

    def _activity7_worker(self):
        try:
            hold = self.get_hold_time()

            self.node.publish_speed(int(float(self.speed_var.get())))

            for name, config in ACT7_CONFIGS.items():
                if not self.running_sequence:
                    break

                self.send_pose(config, f"Ejecutando {name}")
                time.sleep(hold)

            if self.running_sequence:
                self.send_pose([0.0, 0.0, 0.0, 0.0, 0.0], "HOME final")
                self.status_var.set("Secuencia Actividad 7 finalizada.")

        except Exception as e:
            self.status_var.set(f"Error durante la secuencia: {e}")

        finally:
            self.running_sequence = False

    def update_measured_positions(self):
        for joint in JOINTS:
            value = self.node.last_positions_deg.get(joint)

            if value is None:
                self.measured_vars[joint].set("---")
            else:
                self.measured_vars[joint].set(f"{value:.2f}")

        self.root.after(200, self.update_measured_positions)


def main():
    rclpy.init()

    node = PincherGuiNode()

    executor = rclpy.executors.SingleThreadedExecutor()
    executor.add_node(node)

    spin_thread = threading.Thread(target=executor.spin, daemon=True)
    spin_thread.start()

    root = tk.Tk()
    app = SimultaneousControlGUI(root, node)

    def on_close():
        app.running_sequence = False
        executor.shutdown()
        node.destroy_node()
        rclpy.shutdown()
        root.destroy()

    root.protocol("WM_DELETE_WINDOW", on_close)
    root.mainloop()


if __name__ == "__main__":
    main()