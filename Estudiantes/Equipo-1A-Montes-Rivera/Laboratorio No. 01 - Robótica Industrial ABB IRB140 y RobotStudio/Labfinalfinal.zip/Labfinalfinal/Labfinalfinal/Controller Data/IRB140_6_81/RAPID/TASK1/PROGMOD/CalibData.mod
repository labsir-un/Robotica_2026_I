MODULE CalibData
    PERS tooldata MyNewTool:=[TRUE,[[84.182,0,157.42],[0.866025404,0,0.5,0]],[1,[0,0,1],[1,0,0,0],0,0,0]];
    TASK PERS wobjdata Workobject_1:=[FALSE,TRUE,"",[[-19.6,-500.53,513],[1,0,0,0]],[[235,-195,93],[0,0,1,0]]];
ENDMODULE